from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time

driver = webdriver.Chrome()

# Open form
driver.get("file:///C:/Users/ASUS/Desktop/College/Sem6/DevOps/CA2Task_StuRegForm/index.html")

# Test valid submission
driver.find_element(By.ID, "name").send_keys("Palak Gupta")
driver.find_element(By.ID, "email").send_keys("palak@gmail.com")
driver.find_element(By.ID, "mobile").send_keys("9876543210")

driver.find_element(By.ID, "department").send_keys("Computer")

driver.find_element(By.XPATH, "//input[@value='Female']").click()

driver.find_element(By.ID, "feedback").send_keys(
    "This is a very good platform for students to share feedback easily"
)

driver.find_element(By.XPATH, "//button[@type='submit']").click()

time.sleep(20)

print("Test Completed Successfully")

driver.quit()