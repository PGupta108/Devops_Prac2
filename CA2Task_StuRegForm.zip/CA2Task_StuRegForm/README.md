# 🎓 Student Feedback Registration Form (DevOps Project)

## 📌 Project Overview

This project is a **Student Feedback Registration Form** developed as part of a DevOps assignment. It demonstrates the integration of **frontend development, automated testing, and continuous integration**.

The system allows students to submit feedback through a web form, validates user input using JavaScript, automates testing using Selenium, and executes the tests through Jenkins.

---

## 🎯 Objectives

* Design a user-friendly feedback form using HTML and CSS
* Implement client-side validation using JavaScript
* Automate testing using Selenium WebDriver
* Integrate Jenkins to execute automated test cases
* Demonstrate a basic CI/CD workflow

---

## 🛠️ Technologies Used

| Technology | Purpose                   |
| ---------- | ------------------------- |
| HTML       | Structure of the web form |
| CSS        | Styling and UI design     |
| JavaScript | Form validation           |
| Python     | Selenium test scripting   |
| Selenium   | Automated testing         |
| Jenkins    | Continuous Integration    |

---

## 📂 Project Structure

```
Student-Feedback-Form/
│── index.html        # Main form structure
│── style.css         # Styling of the form
│── script.js         # Validation logic
│── test_form.py      # Selenium automation script
│── README.md         # Project documentation
```

---

## 💻 Features

### 🧾 Form Features

* Student Name input
* Email validation
* Mobile number validation (10 digits)
* Department selection (dropdown)
* Gender selection (radio buttons)
* Feedback text (minimum 10 words)

### ✅ Validation Features

* Empty field checking
* Email format validation
* Mobile number numeric validation
* Mandatory selections enforcement
* Feedback length validation

---

## 🧪 Test Cases Implemented (Selenium)

* ✔ Form loads successfully
* ✔ Valid data submission
* ✔ Invalid email format handling
* ✔ Invalid mobile number detection
* ✔ Empty fields validation
* ✔ Dropdown selection functionality
* ✔ Submit and Reset button functionality

---

## ⚙️ Setup & Installation

### 🔹 Step 1: Install Requirements

* Install Python (3.x)
* Install Google Chrome
* Install ChromeDriver (matching Chrome version)
* Install Jenkins

---

### 🔹 Step 2: Install Selenium

Run the following command:

```
pip install selenium
```

---

### 🔹 Step 3: Run the Project

1. Open `index.html` in browser
2. Run Selenium test:

```
python test_form.py
```

---

## 🔄 Jenkins Integration

### Steps Performed:

1. Installed Jenkins locally
2. Created a Freestyle project
3. Configured build step using Windows batch command
4. Provided Python executable path
5. Executed Selenium test script

### Sample Build Command:

```
cd <project-path>
"C:\Path\To\Python\python.exe" test_form.py
```

---

## 📊 Build Result

* ✔ Build Status: **SUCCESS**
* ✔ Selenium tests executed successfully
* ✔ Form validation working as expected

---

## 🔁 CI Workflow

```
User Input → Form Validation → Selenium Test → Jenkins Execution → Build Result (Success/Failure)
```

---

## ⚠️ Challenges Faced

* Jenkins not recognizing Python
* Incorrect Python path (WindowsApps issue)
* ChromeDriver compatibility issues

### ✔ Solutions

* Used full Python executable path
* Installed correct JDK version (Java 17/21)
* Matched ChromeDriver with browser version

---

## 🌟 Improvements Made

* Enhanced UI using modern CSS
* Added proper validation rules
* Structured Selenium test cases
* Integrated automation with Jenkins

---

## 🚀 Future Enhancements

* Add backend (database storage)
* Deploy application online
* Integrate GitHub with Jenkins
* Add email notification system
* Improve UI with frameworks like Bootstrap

---

## 👩‍💻 Author

**Palak Gupta**

---

## 📌 Conclusion

This project successfully demonstrates a basic DevOps pipeline by integrating frontend development, automated testing, and continuous integration using Jenkins. It provides a clear understanding of how testing and automation can improve software quality and reliability.

---