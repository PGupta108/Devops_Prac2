function validateForm() {
    let name = document.getElementById("name").value;
    let email = document.getElementById("email").value;
    let mobile = document.getElementById("mobile").value;
    let dept = document.getElementById("department").value;
    let feedback = document.getElementById("feedback").value;
    let gender = document.getElementsByName("gender");

    let error = document.getElementById("error");

    let emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
    let mobilePattern = /^[0-9]{10}$/;

    // Name
    if (name == "") {
        error.innerHTML = "Name required";
        return false;
    }

    // Email
    if (!email.match(emailPattern)) {
        error.innerHTML = "Invalid Email";
        return false;
    }

    // Mobile
    if (!mobile.match(mobilePattern)) {
        error.innerHTML = "Invalid Mobile Number";
        return false;
    }

    // Gender
    let selected = false;
    for (let i = 0; i < gender.length; i++) {
        if (gender[i].checked) selected = true;
    }
    if (!selected) {
        error.innerHTML = "Select Gender";
        return false;
    }

    // Department
    if (dept == "") {
        error.innerHTML = "Select Department";
        return false;
    }

    // Feedback (10 words)
    if (feedback.split(" ").length < 10) {
        error.innerHTML = "Feedback must be at least 10 words";
        return false;
    }

    alert("Form Submitted Successfully!");
    return true;
}